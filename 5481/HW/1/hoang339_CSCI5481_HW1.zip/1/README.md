This submission is for CSCI 5481's HW1 -- code authored by J.Michael Hoang

To run the main code:
```
python3 count_codons.py input.fna output.csv
```
and to run the auxillary code:
```
python3 organizer.py
```

Input and outputs for genomes are located in their appropriately named folders -- the fake genomes are named in an obvious manner with the expected output under the ***output*** folder. Barplots are within the ***screenshots*** folder and my answer for problem 7 is in the ***written*** folder.